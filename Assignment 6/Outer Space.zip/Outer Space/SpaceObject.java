import java.awt.Graphics;
import java.awt.Color;

class SpaceObject {

	private SimpleShape shape;
	private GraphicsDirection dir;
	private Color color; // foreground color
	private XYOrderedPair speed;
	
	//=======================================================
	//Constructors
	
	public SpaceObject(SimpleShape newSS, GraphicsDirection newDir, XYOrderedPair newSpeed) {
		this.shape = newSS;
		this.dir = newDir;
		this.speed = newSpeed;
		this.color = Color.blue;
	}	
	
	public SpaceObject(SimpleShape newSS, GraphicsDirection newDir) {
		this(newSS, newDir, new XYOrderedPair(2, 2));
	}

	public SpaceObject(SimpleShape newSS) {
		this(newSS, new GraphicsDirection());
	}
	
	public Color getColor() {
		if (this.color == null)
			this.color = Color.blue;
		return this.color;
	}
	
	//=======================================================
	//Constructors
	
	public void setColor(Color c) {
		this.color = c;
	}

	public void drawOn(Graphics g) {
		drawOn(g, this.color);
	}
	
	public void drawOn(Graphics g, Color c) {
		this.shape.drawOn(g, c);
	}	
	
	public void move() {
		Vector v = this.dir.toVector();
		v.multiply(this.speed);
		this.shape.moveBy(v);
	}
		
	public void moveBy(int scalarX, int scalarY) {
		int vectorX, vectorY;
		vectorX = this.dir.convertScalarX(scalarX);
		vectorY = this.dir.convertScalarY(scalarY);
		this.shape.moveBy(new Vector(vectorX, vectorY));
	}

	public Frame getBoundary() {
		return this.shape.getBoundary();
	}

	public void reverseDirectionX() {
		this.dir.reverseX();
	}

	public void reverseDirectionY() {
		this.dir.reverseY();
	}
	
	public void setSpeed(int speed) {
		//Set our speed -- we only have one param, so we set as uniform in x and y
		this.speed = new XYOrderedPair(speed, speed);
	}	
	

}
