
import java.awt.Graphics;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JFrame;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JComponent;
import java.awt.Component;
import java.util.ArrayList;
import java.util.Random;

import java.util.Timer;
import java.util.TimerTask;

public class GraphicsApp extends JPanel
{
	private UserInputBar uiBar;
	private JPanel buttonBar;
	private boolean clear;
	private int interval;
	private int wiggle;
	//private SpaceObject rover;
	private OuterSpace outerSpace;

	public GraphicsApp()
	{
		setInterval(25);
		setWiggle(2);
		setLayout(new BorderLayout());
		this.uiBar = new UserInputBar(this);
		setClear(false);

		/*
		this.addComponentListener(new ComponentAdapter() {
			public void componentResized(ComponentEvent componentEvent) {
			}});
		*/

	}

	public void setButtonBar(JPanel pane) { this.buttonBar = pane; }
	public boolean getClear() { return this.clear; }
	public void setClear(boolean newClear) { this.clear = newClear; }
	public int getInterval() { return this.interval; }
	public void setInterval(int newInterval) { this.interval = newInterval; }
	public int getWiggle() { return this.wiggle; }
	public void setWiggle(int newWiggle) { this.wiggle = newWiggle; }
	
	public OuterSpace getOuterSpace() {
		if (this.outerSpace == null) {
			Frame boundary = new Frame(0, 0, this.getWidth(), this.getHeight()); 
			this.outerSpace = new OuterSpace(boundary, 100);
		}
		return this.outerSpace;
	}

	@Override
	public void paintComponent(Graphics g)
	{
		OuterSpace space = this.getOuterSpace();		
		
		//Update space system with new space object speed
		space.setSpeed(this.getWiggle());
	
		//Erase
		space.drawOn(g, this.getBackground());
		
		//Move
		space.move();
		
		//Draw
		space.drawOn(g);
	}

	public int getToolbarHeight() {
		return this.buttonBar.getHeight();
	}

	public Frame getCanvasFrame() {
		return new Frame(0, 0, this.getWidth(), this.getHeight() - getToolbarHeight());
	}

	public void clear(Graphics g)
	{
		setForeground(Color.yellow);
		setBackground(Color.black);
		g.fillRect(0, 0, getWidth(), getHeight());
		setClear(false);
	}

	private JComponent paneNamed(String paneName)
	{
		for (Component each: buttonBar.getComponents())
			if (each.getName() != null)
				if (each.getName().equals(paneName))
					return (JComponent)each;
		return null;
	}

	public void gatherInput()
	{
		JTextArea textArea = (JTextArea)paneNamed("pInterval");
		this.setInterval(Integer.parseInt(textArea.getText()));
		textArea = (JTextArea)paneNamed("pWiggle");
		this.setWiggle(Integer.parseInt(textArea.getText()));
	}

	public static void main(String[] args)
	{
		GraphicsApp drawer = new GraphicsApp();
		JFrame application = new JFrame();
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		application.add(drawer);
		application.setSize(1000, 750);
		application.setVisible(true);
	}




}



//===========================================================================


class UserInputBar
{
	GraphicsApp owner;
	Timer timer;

	public UserInputBar(GraphicsApp aOwner)
	{
		owner = aOwner;
		constructButtons();
	}

	public void constructButtons()
	{
		//Construct buttons
		JButton button1 = new JButton("Go");
		button1.addActionListener(clickedGo());
		JButton button3 = new JButton("Stop");
		button3.addActionListener(clickedStop());

		JTextArea blank = new JTextArea("  ");

		//Button bar
		JPanel buttonBar = new JPanel();
		buttonBar.setLayout(new FlowLayout(FlowLayout.CENTER));

		addInput(5, "pWiggle", "" + owner.getWiggle(), "Max Move (pixels)", buttonBar);
		buttonBar.add(blank);
		addInput(5, "pInterval", "" + owner.getInterval(), "Interval (ms)", buttonBar);
		buttonBar.add(blank);

		buttonBar.add(button1);
		buttonBar.add(button3);

		owner.add(buttonBar, BorderLayout.SOUTH);
		owner.setButtonBar(buttonBar);
	}

	public JTextArea addInput(int width, String name, String initialValue, String label, JPanel container)
	{
		JTextArea input = new JTextArea(1, width);
		input.setBorder(BorderFactory.createLineBorder(Color.black));
		input.setName(name);
		input.setText(initialValue);
		container.add(new JLabel(label));
		container.add(input);
		return input;
	}

	public void startTimer()
	{
		timer = new Timer();
		//timer task, initial delay , rate (ms)
		timer.schedule(new DrawingTask(), 0, owner.getInterval());
	}

	public void stopTimer()
	{
		if (timer != null)
			timer.cancel();
		timer = null;
	}

	class DrawingTask extends TimerTask
	{
		public void run()
		{
			//chamber.dump("tick");
			//chamber.tick();
			owner.repaint();
		}
	}

	protected ActionListener clickedGo()
	{
		return new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				owner.setClear(true);
				owner.repaint();
				owner.gatherInput();
				startTimer();
			}
		};
	}

	protected ActionListener clickedStop()
	{
		return new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				stopTimer();
			}
		};
	}

	protected ActionListener clickedClear()
	{
		return new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				owner.setClear(true);
				owner.repaint();
			}
		};
	}

}
