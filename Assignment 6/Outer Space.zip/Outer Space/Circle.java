
import java.awt.Graphics;
import java.awt.Color;

class Circle extends SimpleShape {
	private Point c;
	private int r;
	public Circle(Point cc, int rr) {
		this.c = cc;
		this.r = rr;
	}
	public void drawOn(Graphics g, Color color) {
    	Frame f = this.getBoundary();
    	int diam = 2 * this.r;
    	g.setColor(color);
		g.drawOval(f.getLeft(), f.getTop(), diam, diam);
	    g.fillOval(f.getLeft(), f.getTop(), diam, diam);

	}
	public void moveBy(Vector v) {
		this.c.moveBy(v);
	}
	public Frame getBoundary() {
		int cx, cy, rr;
		cx = this.c.getX();
		cy = this.c.getY();
		rr = this.r;
		return new Frame(cx-rr, cy-rr, cx+rr, cy+rr);
	}
}