class GraphicsDirection {

	private boolean xForward;
	private boolean yForward;
	public GraphicsDirection() {
		this.xForward = true;
		this.yForward = true;
	}
	public void reverseX() {
		this.xForward = !this.xForward;
	}

	public void reverseY() {
		this.yForward = !this.yForward;
	}
	int convertScalarX(int scalar) {
		//convert to vector
		return scalar * (this.xForward ? 1 : -1);
	}
	int convertScalarY(int scalar) {
		//convert to vector
		return scalar * (this.yForward ? 1 : -1);
	}

	public Vector toVector() {
		int x, y;
		x = this.xForward ? 1 : -1;
		y = this.yForward ? 1 : -1;
		return new Vector(x, y);
	}
	

}