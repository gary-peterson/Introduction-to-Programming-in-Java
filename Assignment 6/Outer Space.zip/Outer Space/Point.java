/*
Point class: Models a point in a two-dimensional space.
*/

class Point extends XYOrderedPair {

	public Point(int xx, int yy) {
		super(xx, yy);
	}

	public void moveBy(Vector v) {
		this.setX(this.getX() + v.getX());
		this.setY(this.getY() + v.getY());
	}

}