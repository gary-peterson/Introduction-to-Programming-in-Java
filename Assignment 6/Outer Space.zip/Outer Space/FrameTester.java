
class FrameTester {

	public static void main(String[] args) {
		FrameTester tester = new FrameTester();
		tester.test1();
	}

	public static void println(Object o) { System.out.println(o.toString()); }

	public void test1() {
		Frame myFrame = new Frame(0, 0, 100, 50);
		println(myFrame.toString());
	}




}