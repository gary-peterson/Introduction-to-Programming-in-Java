/*
Vector class:
	Models a two dimensional (x, y) vector.
	A vector has a mangnitude and direction.

Because a vector has a direction, it may be
used to "move" objects. (See Point for example).
*/

class Vector extends XYOrderedPair {

	public Vector(int xx, int yy) {
		super(xx, yy);
	}

	public void plus(Vector v) {
		this.setX(this.getX() + v.getX());
		this.setY(this.getY() + v.getY());
	}

	public void multiply(int k) {
		this.setX(this.getX() * k);
		this.setY(this.getY() * k);
	}
	
	public void multiply(XYOrderedPair xy) {
		this.setX(this.getX() * xy.getX());
		this.setY(this.getY() * xy.getY());		
	}

	public void reverse() {
		this.setX(-this.getX());
		this.setY(-this.getY());
	}

}