//This File: SimpleShape.java

import java.awt.Graphics;
import java.awt.Color;

abstract class SimpleShape {
	public abstract void drawOn(Graphics g, Color color);
	public abstract void moveBy(Vector v);
	public abstract Frame getBoundary();
}
