
import java.util.ArrayList;

import static java.lang.System.out;
import static java.lang.Math.*;




public class Lab {

	public static void main(String[] args) {
		Lab lab = new Lab();
		// lab.listDemo1();
		//lab.review1();
		//lab.review2();
		lab.listDemo2();
	}

	public void review1() {
		// x less than equal to 10,000
		int x = 1000;
		while (x <= 10000) {
			out.println("x: " + x);
			x += 1000;
		}
	}

	public void review2() {
		// x less than equal to 10,000
		out.printf("%n%nreview2%n%n");
		for (int x=1000; x<=10000; x+=1000) {
			out.printf("x: %d %d %d%n", x, x/1000, x*1000);
		}
	}

	private void listDemo1() {
		ArrayList<Integer> myList = new ArrayList<>();
		myList.add(10);
		myList.add(20);
		myList.add(30);
		myList.add(40);
		for (Integer each: myList) {
			out.printf("x: %d%n", each);
		}
		
	}
		
	private void listDemo2() {
		ArrayList<String> myList = new ArrayList<>();
		myList.add("Bob");
		myList.add("Mo");
		myList.add("Foo");
		myList.add("Zoo");
		for (String each: myList) {
			out.printf("x: %s%n", each);
		}		
		
		
	}
		

}


