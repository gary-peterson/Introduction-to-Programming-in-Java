import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class OuterSpace {
	
	private ArrayList<SpaceObject> spaceObjects;
	private Frame limits;

	public OuterSpace(Frame limits, int count) {
		super();
		this.limits = limits;
		this.spaceObjects = new ArrayList<>();
    	Random rand = new Random();
    	
    	int maxX, maxY;
    	maxX = this.limits.getRight();
    	maxY = this.limits.getBottom();
    	int maxR = 30; //todo -- hardcoding
    	
		for (int i=1; i<=count; i++) {
			int x, y, r;
			x = rand.nextInt(maxX);
			y = rand.nextInt(maxY);
			r = 1 + rand.nextInt(maxR);
			Point p = new Point(x, y);
			Circle circ = new Circle(p, r);
			SpaceObject so = new SpaceObject(circ);
			this.spaceObjects.add(so);
		}
	}

	public void drawOn(Graphics g) {
		//Draw all our space objects
		for (SpaceObject eachSO: this.spaceObjects)
			eachSO.drawOn(g);
	}	
	
	public void drawOn(Graphics g, Color c) {
		//Draw all our space objects		
		for (SpaceObject eachSO: this.spaceObjects)
			eachSO.drawOn(g, c);
	}
	
	public void move() {
		//Move all of our space objects
		//If they go out of the galaxy, constrain them
		
		for (SpaceObject eachSO: this.spaceObjects) {
			eachSO.move();
			//constrain our guy
			constrain(eachSO);
		}
	}

	private void constrain(SpaceObject spaceObject) {
		//If the spaceObject is leaving our limits, bring her home
		//If the boundary of the so is outide our limits, bring her home
		Frame spaceObjectFrame, spaceLimits;
		spaceLimits = this.limits;
		spaceObjectFrame = spaceObject.getBoundary();
		if (spaceLimits.contains(spaceObjectFrame))
			return;
		//We know she outside
		if (!spaceLimits.containsHoriz(spaceObjectFrame))
			spaceObject.reverseDirectionX();
		if (!spaceLimits.containsVert(spaceObjectFrame))
			spaceObject.reverseDirectionY();		
	}
	
	public void setSpeed(int speed) {
		//Set speed of all space objects
		for (SpaceObject eachSO: this.spaceObjects) {
			eachSO.setSpeed(speed);
		}
	}	

}
