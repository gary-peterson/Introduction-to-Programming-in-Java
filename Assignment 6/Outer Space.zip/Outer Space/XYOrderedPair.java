
/*
Very simple class that really just "holds" and x and y value.
that simply holds an x and y value.
Both are ints.
Subclasses may be Points, Vectors, ...
*/


public class XYOrderedPair {

	private int x;
	private int y;

	public int getX() { return this.x; }

	public int getY() { return this.y; }

	public void setX(int newX) { this.x = newX; }

	public void setY(int newY) { this.y = newY; }

	public XYOrderedPair(int xx, int yy) {
		this.x = xx;
		this.y = yy;
	}

}