
/*
lt left top
rt right top
rb right bottom
lb left bottom

NOTE WELL -- In computer graphics y axis is oriented downward (top to bottom). X is intuitively left to right.
*/

class Frame {

	int leftX, topY, rightX, bottomY;

	public Frame(int newLeftX, int newTopY, int newRightX, int newBottomY) {
		this.leftX = newLeftX;
		this.topY = newTopY;
		this.rightX = newRightX;
		this.bottomY = newBottomY;
	}

	public String toString() {
		String delim = ", ";
		return "(leftX, topY, rightX, bottomY): ("
			+ getLeft() + delim + getTop() + delim
			+ getRight() + delim + getBottom();
	}

	public Point lt() {
		return new Point(getLeft(), getTop());
	}

	public Point rt() {
		return new Point(getRight(), getTop());
	}

	public Point rb() {
		return new Point(getRight(), getBottom());
	}

	public Point lb() {
		return new Point(getLeft(), getBottom());
	}

	public int getLeft() {
		return this.leftX;
	}

	public int getTop() {
		return this.topY;
	}

	public int getRight() {
		return this.rightX;
	}

	public int getBottom() {
		return this.bottomY;
	}

	public boolean intersects(Frame other) {
		return contains(other.lt()) || contains(other.rt()) || contains(other.rb()) || contains(other.lb());
	}

	public boolean contains(Frame other) {
		return this.containsHoriz(other) && this.containsVert(other);
	}

	public boolean containsHoriz(Frame other) {
		return this.containsX(other.getLeft()) && this.containsX(other.getRight());
	}

	public boolean containsVert(Frame other) {
		return this.containsY(other.getTop()) && this.containsY(other.getBottom());
	}

	public boolean contains(Point p) {
		return containsX(p.getX()) && containsY(p.getY());
	}

	public boolean containsX(int x) {
		return x >= getLeft() && x <= getRight();
	}

	public boolean containsY(int y) {
		return y >= getTop() && y <= getBottom();
	}
}