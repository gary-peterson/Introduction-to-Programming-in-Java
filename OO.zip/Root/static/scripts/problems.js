//problems.js

function hideElem(elemId)
{
	var elem = document.getElementById(elemId);
	if (elem != null)
		elem.style.visibility = "hidden";
}


function showElem(elemId)
{
	var elem = document.getElementById(elemId);
	if (elem != null)
		elem.style.visibility = "visible";
}			