/* Hello, I'm a minimal model of a Popcorn Machine
 * For example brevity, I have only a weight. 
 *  */
 
public class PopcornMachine2 implements Weighable {
	private int weight;

	public PopcornMachine2(int aWeight) {
		this.weight = aWeight;
	}
	
	public final int getWeight() {
		return weight;
	}
}
