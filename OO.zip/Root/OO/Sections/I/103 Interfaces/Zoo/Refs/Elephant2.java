/* Hello, I'm a minimal model of an Elephant
 * For example brevity, I have only a weight.
 *  */

public class Elephant2 implements Weighable {
	private int weight;

	public Elephant2(int aWeight) {
		this.weight = aWeight;
	}

	public int getWeight() {
		return weight;
	}
}
