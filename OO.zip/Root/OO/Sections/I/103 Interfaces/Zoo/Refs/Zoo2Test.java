//College2Test -- I test Zoo2

import static java.lang.System.out;

public class Zoo2Test {

	public static void main(String[] args) {
		Zoo2Test test = new Zoo2Test();
		test.test1();
	}

	private void test1() {
		out.printf("test1%n%n");

		//Instantiate a Zoo2 object
		Zoo2 zoo = new Zoo2("Blue Moon Zoo");		
		zoo.add(new Elephant2(5000));
		zoo.add(new PopcornMachine2(75));		
		//etc

		//Ask the zoo for a nice string, which will show the weight
		out.println(zoo.toString());
	}


}
