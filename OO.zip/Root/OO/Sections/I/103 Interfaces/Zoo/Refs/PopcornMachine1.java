/* Hello, I'm a minimal model of a Popcorn Machine
 * For example brevity, I have only a weight.
 *  */

public class PopcornMachine1 {
	private int weight;

	public PopcornMachine1(int aWeight) {
		this.weight = aWeight;
	}

	public int getWeight() {
		return weight;
	}
}
