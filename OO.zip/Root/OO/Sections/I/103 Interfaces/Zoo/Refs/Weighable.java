/* A warm hello
 * I'm a Weighable type (interface)
 * I know how to do one thing: Answer a weight. */

public interface Weighable {
	public int getWeight();
}
