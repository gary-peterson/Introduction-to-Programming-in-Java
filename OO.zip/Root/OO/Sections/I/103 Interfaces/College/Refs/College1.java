/* A very warm hello, I am College1, a minimal model of a college.
 * I have a name and a list of objects representing entities at the
 * college (e.g. classrooms, computers, professors, parking lots, ...) */

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class College1 {
	private String name;
	private List<Object> list;

	public College1(String aName) {
		super();
		this.name = aName;
		this.list = new ArrayList<>();
	}

	public void add(Object o) {
		this.list.add(o);
	}

	public void printFullReport(PrintStream report) {
		/*Compile error, "printOn not understood by Object
		for (Object each: this.list)
			each.printOn(report);		//<---------- compile error here
		*/
		report.println("College: " + this.name);
		report.println("Apologies, printing of list is not yet supported");
		report.println("Objects do not understand \"printOn\"");
	}

}
