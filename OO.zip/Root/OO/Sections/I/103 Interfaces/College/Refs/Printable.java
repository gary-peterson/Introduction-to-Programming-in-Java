import java.io.PrintStream;

/* Interface Printable
 * I know how to print myself on a report */

public interface Printable {
	public void printOn(PrintStream report);
}
