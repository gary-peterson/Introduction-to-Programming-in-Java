//College2Test -- I test College2

import static java.lang.System.out;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

public class College2Test {

	public static void main(String[] args) {
		College2Test test = new College2Test();
		test.test1();
		out.println("");
		//test.test2();
	}

	private void test1() {
		out.printf("test1%n%n");

		//Instantiate a College2 object
		College2 college = new College2("Mountain Tech College");
		college.add(new Professor2("Kofi Kingston"));
		college.add(new Classroom2(101));

		//Ask for a report of the college
		ByteArrayOutputStream contents = new ByteArrayOutputStream();
		PrintStream stream = new PrintStream(contents);
		college.printFullReport(stream);
		String report = new String(contents.toByteArray(), StandardCharsets.UTF_8);

		//Print it
		out.print(report);
	}


}
