/* Hello, I'm Professor2, a minimal model of a classroom.
 * I only am different than Professor1 in one way,
 * I implement the Printable interface */

import java.io.PrintStream;

public class Professor2 implements Printable {
	private String name;

	public Professor2(String aName) {
		this.name = aName;
	}

	public String getName() {
		return name;
	}

	public void printOn(PrintStream report) {
		report.println("I am Professor: " + getName());
	}




}
