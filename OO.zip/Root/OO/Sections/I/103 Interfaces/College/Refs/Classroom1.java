/* Hello, I'm Classroom1, a minimal model of a classroom.
 * I have a roomNumber */

import java.io.PrintStream;

public class Classroom1 {
	private int roomNumber;

	public Classroom1(int aRoomNumber) {
		this.roomNumber = aRoomNumber;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void printOn(PrintStream report) {
		report.println("I am Classroom: " + getRoomNumber());
	}
}
