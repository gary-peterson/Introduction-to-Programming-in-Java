/* Hello, I'm Classroom2, a minimal model of a classroom.
 * I only am different than Classroom1 in one way,
 * I implement the Printable interface */

import java.io.PrintStream;

public class Classroom2 implements Printable {
	private int roomNumber;

	public Classroom2(int aRoomNumber) {
		this.roomNumber = aRoomNumber;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void printOn(PrintStream report) {
		report.println("I am Classroom: " + getRoomNumber());
	}
}
