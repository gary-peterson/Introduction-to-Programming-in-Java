/* Hello, I'm Professor1, a minimal model of a professor.
 * I have a name */

import java.io.PrintStream;

public class Professor1 {
	private String name;

	public Professor1(String aName) {
		this.name = aName;
	}

	public String getName() {
		return name;
	}

	public void printOn(PrintStream report) {
		report.println("I am Professor: " + getName());
	}




}
