/* Dictionary2Test.java
 * Tests on class "Dictionary2" 
 */

import static java.lang.System.out;

public class Dictionary2Test {
	
	public static void main(String[] args) {
		Dictionary2Test test = new Dictionary2Test();
		test.test1();
		out.println("");
		test.test2();	
	}	
	
	public void test1() {
		//Player names mapped to player numbers
		//Setup
		Dictionary2<String, Integer> map = new Dictionary2<>();
		map.put("Rocky", 100);
		map.put("Rambo", 101);		
		//Test
		String key;	//name
		int value;	//id
		key = "Rambo";
		value = map.get(key);
		assertEquals(value, 101, "test1");
		out.printf("%s => %d%n", key, value);		
	}
	
	public void test2() {
		//Player names mapped to player numbers
		//Setup		
		Dictionary2<String, Integer> map = new Dictionary2<>();
		map.put("Kofi", 10);
		//map.put("Yaping", "20");		//<-- compiler finds bug		
		map.put("Yaping", 20);			//<-- simple fix		
		//Test
		String key;	//name
		int value;	//id
		key = "Yaping";
		//Note: we no longer need typecasting as we did for Dictionary1
		value = map.get(key);
		assertEquals(value, 20, "test2");
		out.printf("%s => %d%n", key, value);		
	}
	
	protected void assertEquals(Object actual, Object expected, String msg) {
		out.println(msg);
		out.printf("Actual Value: %s%n", actual);	
		out.printf("Expected Value: %s%n", expected);
		out.printf("Test: %s%n", actual.equals(expected));
	}	

}
