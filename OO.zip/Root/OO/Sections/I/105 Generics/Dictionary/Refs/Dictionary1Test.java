/* Dictionary1Test.java
 * Tests on class "Dictionary1" 
 */

import static java.lang.System.out;

public class Dictionary1Test {
	
	public static void main(String[] args) {
		Dictionary1Test test = new Dictionary1Test();
		test.test1();
		out.println("");
		test.test2();	
	}	
	
	public void test1() {
		//Player names mapped to player numbers
		//Setup
		Dictionary1 map = new Dictionary1();
		map.put("Rocky", 100);
		map.put("Rambo", 101);		
		//Test
		String key;	//name
		int value;	//id
		key = "Rambo";
		value = (int)map.get(key);
		assertEquals(value, 101, "test1");
		out.printf("%s => %d%n", key, value);		
	}
	
	public void test2() {
		//Player names mapped to player numbers
		//Setup		
		Dictionary1 map = new Dictionary1();
		map.put("Kofi", 10);
		map.put("Yaping", "20");		
		//Test
		String key;	//name
		int value;	//id
		key = "Yaping";
		value = (int)map.get(key);
		assertEquals(value, 20, "test2");
		out.printf("%s => %d%n", key, value);		
	}	
	
	protected void assertEquals(Object actual, Object expected, String msg) {
		out.println(msg);
		out.printf("Actual Value: %s%n", actual);	
		out.printf("Expected Value: %s%n", expected);
		out.printf("Test: %s%n", actual.equals(expected));
	}	

}
