/* Dictionary1.java
 * Minimal Dictionary Without Generics
 * 
 * This class models a dictionary/map object
 * This class does not use generics, so keys and values are simply type "Object".
 */

import java.util.ArrayList;
import java.util.List;

public class Dictionary1 {
	List keys;
	List values;
	
	/*Comment 1*/
	
	public Dictionary1() {
		this.keys = new ArrayList();
		this.values = new ArrayList();		
	}
	
	/*Comment 2
	 * Comment 3	
	 */
	
	public void put(Object key, Object value) {
		this.keys.add(key);
		this.values.add(value);
	}
	
	//comment here too, don't forget me
	public Object get(Object key) {
		int index = this.keys.indexOf(key);
		return this.values.get(index); 
	}
	
}
	
	
