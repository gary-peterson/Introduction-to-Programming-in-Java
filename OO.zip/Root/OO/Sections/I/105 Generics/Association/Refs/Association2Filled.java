/* Class: Association2
 	One small tweak to Association1:
 	We make the instance variable "value" a generic type */

public class Association2<Integer> {
	private String key;
	private Integer value;

	public Association2(String aKey, Integer aValue) {
		this.key = aKey;
		this.value = aValue;
	}

	public String getKey() {
		return key;
	}

	public Integer getValue() {
		return value;
	}
}
