//Association2Test tests Association2

import static java.lang.System.out;

public class Association2Test {

	public static void main(String[] args) {
		Association2Test test = new Association2Test();
		test.test1();
		out.println("");
		test.test2();
		out.println("");
		test.testUsage1();
		out.println("");
		test.testUsage2();
	}

	private void test1() {
		out.println("test1");
		String key = "MaxScore";
		Association2<Integer> assoc = new Association2<>(key, 480);
		out.printf("%s => %s%n", key, assoc.getValue());
	}

	private void test2() {
		out.println("test2");
		String key = "1001";
		Association2<String> assoc = new Association2<>(key, "Kofi L Johnson");
		out.printf("%s => %s%n", key, assoc.getValue());
	}

	private void testUsage1() {
		out.println("testUsage");
		String key = "MaxScore";
		Association2<Integer> assoc;
		assoc = new Association2<>(key, 480);
		int value = (int) assoc.getValue();
		out.printf("Score > 500: %s%n", value > 500);
	}

	private void testUsage2() {
		out.println("testUsage");
		String key = "MaxScore";

		//Association2<Integer> assoc = new Association2<>(key, "510");

		Association2<Integer> assoc = new Association2<>(key, 510);

		int value = (int) assoc.getValue();
		out.printf("Score > 500: %s%n", value > 500);
	}

}
