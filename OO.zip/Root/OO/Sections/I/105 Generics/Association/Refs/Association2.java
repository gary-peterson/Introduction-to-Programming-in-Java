/* Class: Association2
 	One small tweak to Association1:
 	We make the instance variable "value" a generic type */

public class Association2<ValueType> {
	private String key;
	private ValueType value;

	public Association2(String aKey, ValueType aValue) {
		this.key = aKey;
		this.value = aValue;
	}

	public String getKey() {
		return key;
	}

	public ValueType getValue() {
		return value;
	}
}
