/* Class: Association3
 	One small tweak to Association2:
 	Give "key" a generic type too */

public class Association3<KeyType, ValueType> {
	private KeyType key;
	private ValueType value;
	public Association3(KeyType aKey, ValueType aValue) {
		this.key = aKey;
		this.value = aValue;
	}
	public KeyType getKey() {
		return key;
	}
	public ValueType getValue() {
		return value;
	}
}
