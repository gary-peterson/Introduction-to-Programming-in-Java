//Association3Test tests Association3

import static java.lang.System.out;

public class Association3Test {

	public static void main(String[] args) {
		Association3Test test = new Association3Test();
		test.test1();
		out.println("");
		test.test2();
		out.println("");
		test.testUsage1();
		out.println("");
		test.testUsage2();
	}

	private void test1() {
		out.println("test1");
		String key = "MaxScore";
		Association3<String, Integer> assoc = new Association3<>(key, 480);
		out.printf("%s => %s%n", key, assoc.getValue());
	}

	private void test2() {
		out.println("test2");
		int key = 1001;
		Association3<Integer, String> assoc = new Association3<>(key, "Kofi L Johnson");
		out.printf("%s => %s%n", key, assoc.getValue());
	}

	private void testUsage1() {
		out.println("testUsage");
		String key = "MaxScore";
		Association3<String, Integer> assoc = new Association3<>(key, 480);
		int value = (int) assoc.getValue();
		out.printf("Score > 500: %s%n", value > 500);
	}

	private void testUsage2() {
		out.println("testUsage");
		String key = "MaxScore";
		//Association3<Integer> assoc = new Association3<>(key, "510");
		Association3<String, Integer> assoc = new Association3<>(key, 510);
		int value = (int) assoc.getValue();
		out.printf("Score > 500: %s%n", value > 500);
	}

}
