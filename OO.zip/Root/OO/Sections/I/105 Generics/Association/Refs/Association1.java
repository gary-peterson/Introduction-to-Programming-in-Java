/* Class: Association1
  Associates a key to a value.
  E.g.
		"PI" => 3.1416
 		"MaxScore" => 480
 		"1001" => "Kofi L Johnson"
 		"FavIceCream" => "Salted Caramel" */

public class Association1 {

	private String key;

	private Object value;

	public Association1(String aKey, Object aValue) {
		this.key = aKey;
		this.value = aValue;
	}
	public String getKey() {
		return key;
	}
	public Object getValue() {
		return value;
	}
}
