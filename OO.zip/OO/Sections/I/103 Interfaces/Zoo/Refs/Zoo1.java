import java.util.ArrayList;
import java.util.List;

/* Hello, I'm a minimal model of an Zoo */

public class Zoo1 {
	private String name;
	private List<Object> objects;

	public Zoo1(String aName) {
		this.name = aName;
		this.objects = new ArrayList<>();
	}

	public void add(Object aObject) {
		this.objects.add(aObject);
	}

	public int getTotalWeight() {
		int totalWeight = 0;
		for (Object eachObject: this.objects)
			totalWeight += eachObject.getWeight();
		return totalWeight;
	}
}
