import java.util.ArrayList;
import java.util.List;

/* Hello, I'm a minimal model of an Zoo. I am
 * different from try #1 in that I use an interface in
 * this "getTotalWeight" method */

public class Zoo2 {
	private String name;
	private List<Weighable> objects;

	public Zoo2(String aName) {
		this.name = aName;
		this.objects = new ArrayList<>();
	}

	public void add(Weighable aObject) {
		this.objects.add(aObject);
	}

	public int getTotalWeight() {
		int totalWeight = 0;
		for (Weighable eachObject: this.objects)
			totalWeight += eachObject.getWeight();
		return totalWeight;
	}

	public String toString() {
		return String.format("%s -- Total Weight of Objects = %d",
								this.name, getTotalWeight());
	}

}
