/* Hello, I'm a minimal model of an Elephant
 * For example brevity, I have only a weight.
 *  */

public class Elephant1 {
	private int weight;

	public Elephant1(int aWeight) {
		this.weight = aWeight;
	}

	public int getWeight() {
		return weight;
	}
}
