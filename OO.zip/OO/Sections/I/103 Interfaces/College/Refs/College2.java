/* Greetings, I'm class College2, a minimal model of a college.
 * I am only slightly different than College1. My
 * ivar is a list of Printables. */

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class College2 {
	private String name;
	private List<Printable> list;

	public College2(String aName) {
		super();
		this.name = aName;
		this.list = new ArrayList<>();
	}

	public void add(Printable o) {
		this.list.add(o);
	}

	public void printFullReport(PrintStream stream) {
		//printOn is understood by Printable dudes, so we're good to go
		stream.println("College: " + this.name);
		stream.println("I have a list of entities of size: " + this.list.size());
		stream.printf("%nHere is my list:%n%n");
		for (Printable each: this.list)
			each.printOn(stream);
	}

}
