/* Class: Association1Test
  	tests Association1 */

import static java.lang.System.out;

public class Association1Test {

	public static void main(String[] args) {
		Association1Test test = new Association1Test();
		test.test1();
		out.println("");
		test.test2();
		out.println("");
		test.testUsage1();
		out.println("");
		test.testUsage2();
	}

	private void test1() {
		out.println("test1");
		Association1 assoc;
		assoc = new Association1("MaxScore", 480);
		Object value;
		value = assoc.getValue();
		out.printf("%s => %s%n", "MaxScore", value);
	}

	private void test2() {
		out.println("test2");
		String key = "1001";
		Association1 assoc = new Association1(key, "Kofi L Johnson");
		out.printf("%s => %s%n", key, assoc.getValue());
	}

	private void testUsage1() {
		out.println("testUsage");
		String key = "MaxScore";
		Association1 assoc;
		assoc = new Association1(key, 480);
		int value;
		value = (int) assoc.getValue();

		out.printf("Score > 500: %s%n", value > 500);
	}

	private void testUsage2() {
		out.println("testUsage");
		String key = "MaxScore";
		Association1 assoc;
		assoc = new Association1(key, "510");
		int value;
		value = (int) assoc.getValue();
		out.printf("Score > 500: %s%n", value > 500);
	}

}
