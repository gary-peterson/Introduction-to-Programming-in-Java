public class Dictionary2<K, V> {
	List<K> keys;
	List<V> values;
//...
}