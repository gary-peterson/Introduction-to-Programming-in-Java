/* Dictionary2.java
 * Minimal Dictionary With Generics
 * 
 * This class models a dictionary/map object
 * This class does YES use generics, so key 
 * and value types are dynamically set by
 * the user of the class.
 */

import java.util.ArrayList;
import java.util.List;

public class Dictionary2<K, V> {
	List<K> keys;
	List<V> values;

	public Dictionary2() {
		this.keys = new ArrayList<K>();
		this.values = new ArrayList<V>();
	}

	public void put(K key, V value) {
		//Heyo
		this.keys.add(key);
		/* Heyo */
		this.values.add(value);
	}

	public V get(K key) {
		int matchIndex = this.keys.indexOf(key);
		return this.values.get(matchIndex);
	}

}
