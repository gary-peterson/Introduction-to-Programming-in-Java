1. Download the the file "OO.zip"

2. Extract the contents (i.e. a directory named "Root") anywhere on your computer.

3. Open/Run this HTML file in an internet browser:

	Root\OO\index.html

Note:
	Just flip the slashes if using MAC/unix:
		Root\OO\index.html