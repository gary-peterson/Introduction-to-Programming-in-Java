/*
lt left top
rt right top
rb right bottom
lb left bottom
*/
class Frame {
	int l, t, r, b;
	public Frame(int al, int at, int ar, int ab) {
		this.l = al;
		this.t = at;
		this.r = ar;
		this.b = ab;
	}
	public Point lt() { return new Point(this.l, this.t); }
	public Point rt() { return new Point(this.r, this.t); }
	public Point rb() { return new Point(this.r, this.b); }
	public Point lb() { return new Point(this.l, this.b); }
	public int getLeft() { return this.l; }
	public int getTop() { return this.t; }
	public int getRight() { return this.r; }
	public int getBottom() { return this.b; }
	public boolean intersects(Frame other) {
		return contains(other.lt())
				|| contains(other.rt())
				|| contains(other.rb())
				|| contains(other.lb());
	}
	public boolean contains(Frame other) {
		return this.containsHoriz(other)
				&& this.containsVert(other);
	}
	public boolean containsHoriz(Frame other) {
		return this.containsX(other.getLeft())
				&& this.containsX(other.getRight());
	}
	public boolean containsVert(Frame other) {
		return this.containsY(other.getTop())
				&& this.containsY(other.getBottom());
	}
	public boolean contains(Point p) {
		return containsX(p.x) && containsY(p.y);
	}
	public boolean containsX(int x) {
		return x>=this.l && x<=this.r;
	}
	public boolean containsY(int y) {
		return y>=this.t && y<=this.b;
	}
}