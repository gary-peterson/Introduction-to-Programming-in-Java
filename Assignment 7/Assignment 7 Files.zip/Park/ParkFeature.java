
/*
ParkFeature.java
Class: ParkFeature

We have two instance variables

	name -- e.g. "Beach", "Snack Bar", "Disc Golf Course", "Picnic Grounds", etc
	closed -- e.g. true if we are closed

When first constructed, we initialize ourself to closed
So a client (user of this object) must explicitly send
a message to use to set us to open
	i.e. the "open" message
*/

public class ParkFeature
{
	//Instance Variables
	private String name;
	boolean closed;				//Tells is if the park feature is open or closed
								//If closed = true, the park feature is closed
								//If closed = false, the park feature is open

	public ParkFeature(String newName)
	{
		this.name = newName;
		this.closed = false;
	}

	//Commands (directives) we can give to a feature

	public void open()
	{
		this.closed = false;
	}

	public void close()
	{
		this.closed = true;
	}

	public void setClosed(boolean newClosed)
	{
		this.closed = newClosed;
	}

	//Questions we can ask a feature

	public boolean isClosed()
	{
		return this.closed;
	}

	public boolean isOpen()
	{
		return !this.isClosed();
	}

	public boolean hasName(String aName)
	{
		return this.name.equalsIgnoreCase(aName);
	}

	public String toString()
	{
		return this.name;
	}

}